/**
 * app/search.js
 * Motor de búsqueda semántica ligera para Huella Conserva
 * 
 * Técnicas aplicadas:
 *  1. Normalización (sin acentos, sin puntuación, minúsculas)
 *  2. Sinónimos y expansión de términos institucionales
 *  3. TF-IDF simplificado (peso por rareza del término)
 *  4. Búsqueda difusa (Levenshtein ligero para typos)
 *  5. Boost por posición (preguntas que empiezan igual)
 *  6. Multi-resultado con score ranking
 * 
 * Diseñado para funcionar sin librerías externas y ser
 * eficiente en Android 8+ con RAM limitada.
 */

// ─── Sinónimos institucionales ────────────────────────────────────────────────
const SYNONYMS = {
  // Caja chica
  'efectivo': ['caja chica', 'fondo', 'dinero'],
  'reembolso': ['devolucion', 'reintegro', 'pago', 'cobro'],
  'comprobante': ['factura', 'cfdi', 'ticket', 'recibo', 'vale'],
  'gasto': ['erogacion', 'desembolso', 'pago', 'compra'],
  'arqueo': ['revision', 'verificacion', 'auditoria', 'conteo'],
  // Viáticos
  'viaticos': ['gastos de viaje', 'viaje', 'comision', 'desplazamiento'],
  'hospedaje': ['hotel', 'alojamiento', 'habitacion', 'noche'],
  'alimentos': ['comida', 'alimento', 'desayuno', 'comida', 'cena', 'alimentacion'],
  'transporte': ['vuelo', 'avion', 'autobus', 'camion', 'traslado', 'pasaje'],
  // Sanciones
  'sancion': ['falta', 'infraccion', 'conducta', 'violacion', 'incumplimiento'],
  'despido': ['baja', 'rescision', 'terminacion', 'separacion'],
  'amonestacion': ['llamada de atencion', 'llamado', 'advertencia', 'acta'],
  // Créditos
  'credito': ['prestamo', 'financiamiento', 'credito', 'monto', 'capital'],
  'plazo': ['tiempo', 'semanas', 'meses', 'duracion', 'periodo'],
  'interes': ['tasa', 'costo', 'porcentaje', 'cargo'],
  'requisito': ['condicion', 'necesito', 'solicitar', 'tramitar', 'aplicar'],
  'garantia': ['aval', 'fiador', 'respaldo', 'seguridad'],
  'mora': ['atraso', 'retraso', 'incumplimiento', 'vencido'],
  'cien': ['100', 'cien pesos'],
  'dos mil': ['2000', '2,000'],
  'facturar': ['factura', 'comprobante', 'cfdi', 'ticket', 'recibo'],
  'deposito': ['depositar', 'pago', 'transferencia', 'reembolso'],
  'guardar': ['resguardar', 'custodiar', 'almacenar', 'conservar'],
  'dias habiles': ['dias', 'tiempo', 'plazo'],
  'limite': ['maximo', 'tope', 'hasta'],
  'dinero': ['fondos', 'efectivo', 'monto', 'importe'],
  'seguro': ['seguro de vida', 'proteccion', 'cobertura'],
  // Generales
  'maximo': ['tope', 'limite', 'hasta', 'no mas de'],
  'minimo': ['desde', 'al menos', 'por lo menos'],
  'autorizar': ['aprobar', 'permitir', 'facultar', 'validar'],
  'prohibido': ['no permitido', 'no se puede', 'no aplica', 'vedado'],
  'proceso': ['procedimiento', 'pasos', 'como', 'tramite'],
  'responsable': ['encargado', 'quien', 'a cargo', 'titular'],
};

// ─── Stop words en español ────────────────────────────────────────────────────
const STOP_WORDS = new Set([
  'de','la','el','en','y','a','los','del','las','un','por','con','una','para',
  'es','al','lo','como','más','o','pero','sus','le','ya','fue','se','ha','que',
  'su','si','sobre','este','entre','cuando','todo','esta','ser','son','dos',
  'me','también','fue','había','era','muy','sin','hay','nos','mi','te',
  'porque','qué','cuál','cuanto','donde','quien','cuales','cual'
]);

// ─── Normalizar texto ─────────────────────────────────────────────────────────
export function normalize(text) {
  return (text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')   // quitar acentos
    .replace(/[¿¡?!.,;:()'"]/g, ' ')  // quitar puntuación
    .replace(/\s+/g, ' ')
    .trim();
}

// ─── Tokenizar y filtrar stop words ──────────────────────────────────────────
export function tokenize(text, minLen = 3) {
  return normalize(text)
    .split(' ')
    .filter(w => w.length >= minLen && !STOP_WORDS.has(w));
}

// ─── Expandir query con sinónimos ─────────────────────────────────────────────
export function expandQuery(tokens) {
  const expanded = new Set(tokens);
  for (const token of tokens) {
    for (const [key, syns] of Object.entries(SYNONYMS)) {
      const normKey = normalize(key);
      if (normKey.includes(token) || token.includes(normKey)) {
        syns.forEach(s => normalize(s).split(' ').forEach(w => w.length >= 3 && expanded.add(w)));
      }
      for (const syn of syns) {
        const normSyn = normalize(syn);
        if (normSyn.includes(token) || token.includes(normSyn)) {
          normalize(key).split(' ').forEach(w => w.length >= 3 && expanded.add(w));
          syns.forEach(s => normalize(s).split(' ').forEach(w => w.length >= 3 && expanded.add(w)));
        }
      }
    }
  }
  return [...expanded];
}

// ─── Distancia Levenshtein ligera (máx 2 edits para typos) ───────────────────
function levenshtein(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 99; // early exit
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[m][n];
}

// ─── Match difuso: ¿token coincide con palabra del texto? ─────────────────────
function fuzzyMatch(token, text, threshold = 2) {
  if (text.includes(token)) return true;
  if (token.length <= 4) return false; // no fuzzy para palabras cortas
  const words = text.split(' ');
  return words.some(w => w.length >= token.length - 2 && levenshtein(token, w) <= threshold);
}

// ─── Calcular IDF (rareza del término en el corpus) ──────────────────────────
function computeIDF(token, allTexts) {
  const docsWithToken = allTexts.filter(t => t.includes(token)).length;
  if (docsWithToken === 0) return 0;
  return Math.log((allTexts.length + 1) / (docsWithToken + 1)) + 1;
}

/**
 * Motor principal de búsqueda semántica.
 * 
 * @param {string} query - Pregunta del usuario
 * @param {Array<{q: string, a: string}>} faqs - Lista de FAQs del módulo
 * @param {Object} options - Opciones de configuración
 * @returns {Array<{faq, score, exact}>} - Resultados ordenados por relevancia
 */
export function semanticSearch(query, faqs, options = {}) {
  const {
    topK = 3,           // máximo de resultados
    minScore = 0.25,    // score mínimo para incluir resultado
    fuzzy = true,       // búsqueda difusa para typos
    expandSynonyms = true, // expansión de sinónimos
  } = options;

  if (!faqs || faqs.length === 0) return [];

  const qNorm = normalize(query);
  const qTokens = tokenize(query);
  const qTokensExpanded = expandSynonyms ? expandQuery(qTokens) : qTokens;

  // Pre-normalizar todos los textos de FAQ para IDF
  const allTexts = faqs.map(f => normalize(f.q + ' ' + f.a));

  const results = faqs.map((faq, idx) => {
    const faqText = normalize(faq.q + ' ' + faq.a);
    const faqTokens = tokenize(faq.q + ' ' + faq.a);

    let score = 0;

    // 1. Coincidencia exacta de frase completa (máximo boost)
    if (faqText.includes(qNorm)) {
      score += 2.0;
    }

    // 2. TF-IDF por token
    for (const token of qTokensExpanded) {
      const idf = computeIDF(token, allTexts);
      
      // Coincidencia exacta en pregunta (más peso) vs respuesta
      const inQ = normalize(faq.q).includes(token);
      const inA = normalize(faq.a).includes(token);
      
      if (inQ) score += idf * 1.5;
      else if (inA) score += idf * 0.8;
      else if (fuzzy && fuzzyMatch(token, faqText)) score += idf * 0.4;
    }

    // 3. Boost si la pregunta empieza con tokens similares
    const faqStart = normalize(faq.q).substring(0, 40);
    const qStart = qNorm.substring(0, 40);
    const startTokens = tokenize(qStart);
    const startMatches = startTokens.filter(t => faqStart.includes(t)).length;
    if (startMatches > 0) score += startMatches * 0.3;

    // 4. Boost por cobertura: % de tokens de la query presentes en la FAQ
    const coverage = qTokens.length > 0
      ? qTokens.filter(t => faqText.includes(t)).length / qTokens.length
      : 0;
    score += coverage * 1.2;

    // 5. Penalización por longitud (respuestas muy cortas pueden ser menos relevantes)
    if (faq.a.length < 30) score *= 0.85;

    return { faq, score, idx };
  });

  return results
    .filter(r => r.score >= minScore)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

/**
 * Búsqueda cross-módulo: busca en todos los FAQs disponibles.
 * Útil cuando el usuario hace una pregunta sin seleccionar módulo.
 * 
 * @param {string} query
 * @param {Object} allFaqs - { MODULE_ID: [{q, a}] }
 * @returns {Array<{moduleId, faq, score}>}
 */
export function crossModuleSearch(query, allFaqs) {
  const allResults = [];

  for (const [moduleId, faqs] of Object.entries(allFaqs)) {
    const results = semanticSearch(query, faqs, { topK: 2, minScore: 0.3 });
    results.forEach(r => allResults.push({ moduleId, ...r }));
  }

  return allResults
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

/**
 * Extrae sugerencias de preguntas similares para mostrar al usuario.
 * Útil cuando no hay buena coincidencia.
 */
export function getSuggestions(query, faqs, topK = 3) {
  const results = semanticSearch(query, faqs, { topK, minScore: 0.1, expandSynonyms: true });
  return results.map(r => r.faq.q);
}
