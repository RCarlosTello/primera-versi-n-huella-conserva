import { 
    handleMANLineasPrompt, handleMANTemasPrompt,
    detectLinea, detectManualDesdeQuery,
    handleMAN, handleVIA, handleSAN, handleCON,
    MAN_LINEAS, MANUAL_KEYWORDS, CON_TOPICS
} from './modules.js';
import { 
    renderMessage, renderMenu, renderTopicButtons, renderDualCollapsibleMenu, 
    renderFileAttachment, showTyping, hideTyping, clearMessages, 
    setBreadcrumb, getBreadcrumb, setModBtnActive, enableModBtns, 
    disableModBtns, showSessionPanel, hideSessionPanel, updateSessionTimer,
    renderRibbon
} from './ui.js';
import { lookupCollaborator, SessionManager, checkIsBirthday } from './auth.js';
import { crossModuleSearch } from './search.js';
import { FAQS } from '../data/faqs.js';

const STATE = {
    UNAUTHENTICATED: 'UNAUTHENTICATED',
    AUTHENTICATED: 'AUTHENTICATED',
    WAITING_LINEA: 'WAITING_LINEA'
};

const MODULE_NAMES = {
    'CON': 'Conócenos', 'MAN': 'Manuales', 'VIA': 'Viáticos',
    'CAJA': 'Caja Chica', 'AUD': 'Auditoría', 'SAN': 'Sanciones'
};

const FAQ_TO_MODULE = {
    'MAN_CAJ': 'CAJA', 'MAN_AUD': 'AUD', 'MAN_VIA': 'VIA',
    'MAN_SOL': 'MAN', 'MAN_IND': 'MAN', 'MAN_TAC': 'MAN',
    'MAN_HOG': 'MAN', 'MAN_PAR': 'MAN',
};

export class ChatEngine {
    constructor() {
        this._state = STATE.UNAUTHENTICATED;
        this._session = null;
        this._module = null;
        this._linea = null;
        this._pendingQuery = null;
        this._currentOptions = null;
        this._queryHistory = [];
    }

    async init() {
        const savedSession = sessionStorage.getItem('hc-session');
        if (savedSession) {
            try {
                const collab = JSON.parse(savedSession);
                await this._onLoginSuccess(collab);
            } catch (err) {
                sessionStorage.removeItem('hc-session');
                this._state = STATE.UNAUTHENTICATED;
            }
        } else {
            this._state = STATE.UNAUTHENTICATED;
        }
    }

    async login(email, pass) {
        const collab = await lookupCollaborator(email, pass);
        if (!collab) throw new Error('Credenciales inválidas.');
        sessionStorage.setItem('hc-session', JSON.stringify(collab));
        localStorage.setItem('hc-session-offline', JSON.stringify(collab));
        await this._onLoginSuccess(collab);
    }

    async _onLoginSuccess(collab) {
        this._session = new SessionManager(() => this.onLogoutClick());
        this._session.start(collab);
        this._state = STATE.AUTHENTICATED;
        
        const loginScreen = document.getElementById('login-screen');
        if (loginScreen) loginScreen.classList.add('hidden');
        document.getElementById('app-shell').style.display = 'flex';

        enableModBtns();
        showSessionPanel(collab);
        this._startTimerDisplay();

        const cumple = await checkIsBirthday(collab.fecha_nacimiento);
        let welcome = `¡Hola! 👋🌿\nBienvenido(a), *${collab.nombre}* al Ecosistema Huella CONSERVA.\n> \n> Estoy listo para apoyarte con información institucional, manuales, políticas, viáticos y cualquier consulta de Grupo CONSERVA.\n>\n> 💡 **Tip:** Puedes preguntarme directamente sin seleccionar módulo, por ejemplo:\n> _"¿Cuál es el monto máximo de caja chica?"_ o _"¿Qué viáticos me corresponden a Puebla?"_`;
        if (cumple) welcome += `\n> \n> 🎂 En nombre de Grupo CONSERVA, **¡Feliz cumpleaños!** 🎉`;
        
        renderMessage('bot', welcome);
        setBreadcrumb('Menú Principal');
        this._showMenu();
    }

    _showMenu() {
        clearMessages();
        renderRibbon((id) => this.openModule(id));
    }

    async openModule(moduleId) {
        if (this._state === STATE.UNAUTHENTICATED) {
            renderMessage('bot', 'Por favor, primero autentícate con tu correo institucional.');
            return;
        }
        this._module = moduleId;
        this._linea = null;
        this._pendingQuery = null;
        setModBtnActive(moduleId);
        clearMessages();
        setBreadcrumb(MODULE_NAMES[moduleId] || moduleId);

        if (moduleId === 'CON') {
            renderTopicButtons(CON_TOPICS.map(t => t.label), (num, text) => this.process(text), 'Selecciona el área de interés:');
        } else if (moduleId === 'MAN') {
            renderMessage('bot', 'Has seleccionado **Manuales Institucionales**. ¿Sobre qué línea de crédito o producto deseas consultar?');
            renderTopicButtons(MAN_LINEAS.map(l => l.label), (num, text) => this.process(text));
        } else if (moduleId === 'CAJA') {
            this._module = 'MAN';
            this._linea = { id: 'MAN_CAJ', label: 'Caja Chica' };
            const res = handleMANTemasPrompt(this._linea);
            renderMessage('bot', res.content);
            renderTopicButtons(res.botonesTemas, (num, text) => this.process(text));
        } else if (moduleId === 'AUD') {
            this._module = 'MAN';
            this._linea = { id: 'MAN_AUD', label: 'Auditoría Interna' };
            const res = handleMANTemasPrompt(this._linea);
            renderMessage('bot', res.content);
            renderTopicButtons(res.botonesTemas, (num, text) => this.process(text));
        } else if (moduleId === 'SAN') {
            renderTopicButtons(
                ['Búsqueda por Folio', 'Reglas Generales de Conducta', 'Nivel de Sanciones Grave', 'Formatos para Descarga', 'Regresar al Menú Principal'],
                (num, text) => this.process(text),
                'Has seleccionado **Matriz de Sanciones**. ¿Qué deseas consultar?'
            );
        } else if (moduleId === 'VIA') {
            renderTopicButtons([
                'Topes de Hospedaje por Ciudad', 'Viáticos de Alimentos', 'Reglas de Transporte',
                'Calcular Viáticos (ruta y días)', 'Anticipación y Comprobación',
                'Viáticos Internacionales', 'Regresar al Menú Principal'
            ], (num, text) => this.process(text), '✈️ Has seleccionado **Política de Viáticos**. ¿Sobre qué tema deseas consultar?');
        } else {
            renderMessage('bot', `Has seleccionado **${MODULE_NAMES[moduleId]}**. Dime qué información necesitas.`);
        }
    }

    async process(input) {
        if (this._state === STATE.UNAUTHENTICATED) {
            if (input.includes('@grupoconserva.mx')) {
                const loginScreen = document.getElementById('login-screen');
                if (loginScreen) {
                    loginScreen.classList.remove('hidden');
                    loginScreen.style.display = 'flex';
                    const emailInput = document.getElementById('login-email');
                    if (emailInput) { emailInput.value = input; document.getElementById('login-pass')?.focus(); }
                }
            } else {
                renderMessage('bot', 'Acceso restringido. Por favor, inicia sesión con tus credenciales institucionales.');
            }
            return;
        }

        this._session?.reset();
        this._queryHistory.push(input);
        if (this._queryHistory.length > 10) this._queryHistory.shift();

        showTyping();
        try {
            await this._handleAuthenticatedQuery(input);
        } finally {
            hideTyping();
        }
    }

    _startTimerDisplay() {
        setInterval(() => {
            const rem = this._session?.getRemainingTime();
            if (rem !== undefined) updateSessionTimer(rem);
        }, 1000);
    }

    onLogoutClick() {
        sessionStorage.removeItem('hc-session');
        localStorage.removeItem('hc-session-offline');
        window.location.reload();
    }

    /**
     * Detecta la intención real del usuario independientemente del módulo activo.
     * Retorna el moduleId correcto o null si no detecta cambio de contexto.
     */
    _detectIntention(input, collab) {
        const q = input.toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '');

        // Indicadores de viáticos — alta prioridad
        const viaKeywords = ['viatico','viaticos','hospedaje','hotel','alojamiento',
            'alimento','comida','desayuno','cena','transporte','vuelo','avion',
            'merida','tabasco','chiapas','puebla','cdmx','oaxaca','campeche',
            'cuanto me toca','cuanto corresponde','cuanto puedo gastar',
            'voy a','viajo a','viaje a','me mandan a','me envian a'];
        if (viaKeywords.some(k => q.includes(k))) {
            // Solo redirigir si NO estamos ya en VIA
            if (this._module !== 'VIA') return 'VIA';
        }

        // Indicadores de sanciones
        const sanKeywords = ['sancion','falta','folio','conducta','amonestacion',
            'despido','baja','acta','llamada de atencion','infraccion','castigo'];
        if (sanKeywords.some(k => q.includes(k))) {
            if (this._module !== 'SAN') return 'SAN';
        }

        // Indicadores de conocenos
        const conKeywords = ['mision','vision','historia','valores','conserva nacio',
            'cuando se fundo','fundacion','proposito','mantra'];
        if (conKeywords.some(k => q.includes(k))) {
            if (this._module !== 'CON') return 'CON';
        }

        return null; // Sin cambio de contexto detectado
    }

    /**
     * Ejecuta el handler correcto según moduleId, sin cambiar el estado actual.
     */
    async _handleByModule(moduleId, input, collab) {
        if (moduleId === 'VIA') return handleVIA(input, collab);
        if (moduleId === 'SAN') return await handleSAN(input);
        if (moduleId === 'CON') return handleCON(input);
        return null;
    }

    async _crossModuleFallback(input) {
        try {
            const crossResults = crossModuleSearch(input, FAQS);
            if (crossResults.length > 0) {
                const best = crossResults[0];
                const moduleLabel = FAQ_TO_MODULE[best.moduleId]
                    ? MODULE_NAMES[FAQ_TO_MODULE[best.moduleId]]
                    : best.moduleId;

                let content = `🔍 **Encontré información relacionada en ${moduleLabel}:**\n\n💬 ${best.faq.a}`;

                if (crossResults.length > 1) {
                    content += `\n\n---\n📌 **También encontré en otros módulos:**\n`;
                    crossResults.slice(1, 3).forEach((r, i) => {
                        const mLabel = FAQ_TO_MODULE[r.moduleId]
                            ? MODULE_NAMES[FAQ_TO_MODULE[r.moduleId]]
                            : r.moduleId;
                        content += `\n**${i + 2}. [${mLabel}]** ${r.faq.q}\n> ${r.faq.a}\n`;
                    });
                }

                renderMessage('bot', content, `Búsqueda Global — ${moduleLabel}`);

                const targetModule = FAQ_TO_MODULE[best.moduleId];
                if (targetModule) {
                    renderTopicButtons(
                        [`Ir a ${MODULE_NAMES[targetModule]}`, 'Menú Principal'],
                        (num, text) => {
                            if (text.includes('Menú')) { this._showMenu(); return; }
                            this.openModule(targetModule);
                        },
                        '¿Deseas profundizar en este tema?'
                    );
                }
                return true;
            }
        } catch(e) {
            console.warn('[Search] Cross-module search error:', e);
        }
        return false;
    }

    async _handleAuthenticatedQuery(input) {
        const collab = this._session?.collaborator;
        const low = input.toLowerCase();

        if (low.includes('regresar') && (low.includes('menú') || low.includes('menu'))) {
            this._module = null;
            this._state = STATE.AUTHENTICATED;
            setBreadcrumb('Menú Principal');
            setModBtnActive(null);
            this._showMenu();
            return;
        }

        // ── DETECCIÓN INTELIGENTE DE INTENCIÓN ──────────────────────────────────
        // Si el usuario está en un módulo pero pregunta algo de OTRO módulo,
        // responder desde el módulo correcto aunque no sea el activo.
        const detectedModule = this._detectIntention(input, collab);
        if (detectedModule && detectedModule !== this._module) {
            const result = await this._handleByModule(detectedModule, input, collab);
            if (result) {
                const modNames = { VIA:'Viáticos', SAN:'Sanciones', CON:'Conócenos', MAN:'Manuales' };
                const note = this._module
                    ? `\n\n> 💡 *Tu pregunta fue sobre **${modNames[detectedModule] || detectedModule}**, aunque estabas en otro módulo. Respondí desde el módulo correcto.*`
                    : '';
                renderMessage('bot', result.content + note, result.source);
                if (result.adjunto) renderFileAttachment(result.adjunto.nombre, result.adjunto.url, result.adjunto.descripcion);
                if (result.formatos) result.formatos.forEach(f => renderFileAttachment(f.archivo, f.url, f.descripcion));
                if (result.botonesTemas) renderTopicButtons(result.botonesTemas, (num, text) => this.process(text));
                return;
            }
        }

        // Smart context: detect if user is asking about a different module
        // than the one currently active — auto-switch or suggest switch
        const isViaticosQuery = /viatic|hosped|hotel|aliment|viajar|viaje|merida|puebla|tabasco|cdmx|chiapas|ciudad.*mexico|dias.*viaje|noches/i.test(input);
        const isSancionQuery  = /sancion|falta|folio|conducta|leve|grave|moderado|llegada.*tarde|tardanza|amonest|llamada.*atencion/i.test(input);
        const isCajaQuery     = /caja chica|caja.*chica|reembolso.*caja|fondo.*caja|efectivo.*caja/i.test(input);

        // Auto-switch module for clear cross-module queries
        if (isViaticosQuery && this._module !== 'VIA' && this._module !== null) {
            const prevModule = this._module;
            this._module = 'VIA';
            this._linea = null;
            setModBtnActive('VIA');
            setBreadcrumb('Viáticos');
        } else if (isSancionQuery && this._module !== 'SAN' && this._module !== null) {
            this._module = 'SAN';
            this._linea = null;
            setModBtnActive('SAN');
            setBreadcrumb('Sanciones');
        } else if (isCajaQuery && this._module !== 'MAN') {
            this._module = 'MAN';
            this._linea = { id: 'MAN_CAJ', label: 'Caja Chica' };
            setModBtnActive('CAJA');
            setBreadcrumb('Caja Chica');
        }

        let result = null;
        if (this._module === 'CON') {
            result = handleCON(input);
        } else if (this._module === 'VIA') {
            result = handleVIA(input, collab);
        } else if (this._module === 'SAN') {
            result = await handleSAN(input);
        } else if (this._module === 'MAN' || detectManualDesdeQuery(input)) {
            if (this._module !== 'MAN') this._module = 'MAN';
            if (!this._linea) {
                const det = detectLinea(input);
                if (det) {
                    this._linea = det;
                    result = handleMAN(input, det, collab);
                } else {
                    const { linea, opciones, ambiguo } = detectManualDesdeQuery(input);
                    if (linea) {
                        this._linea = linea;
                        result = handleMAN(input, linea, collab);
                    } else {
                        this._state = STATE.WAITING_LINEA;
                        this._pendingQuery = input;
                        renderMessage('bot', `Para darte información precisa sobre **"${input}"**, dime sobre cuál línea de crédito deseas consultar:`);
                        renderTopicButtons(
                            [...(opciones || MAN_LINEAS).map(l => l.label), 'Regresar'],
                            (num, text) => {
                                if (text.includes('Regresar')) { this._showMenu(); return; }
                                this.process(text);
                            }
                        );
                        return;
                    }
                }
            } else {
                result = handleMAN(input, this._linea, collab);
            }
        }

        if (result) {
            const currentBreadcrumb = getBreadcrumb() || this._module || 'General';
            const header = `**Sistema:** Huella Conserva Asistente Institucional | v1.2 | 2026 | Activo\n📍 ${currentBreadcrumb}\n\n`;
            renderMessage('bot', header + result.content, result.source);
            if (result.adjunto) renderFileAttachment(result.adjunto.nombre, result.adjunto.url, result.adjunto.descripcion);
            if (result.formatos) result.formatos.forEach(f => renderFileAttachment(f.archivo, f.url, f.descripcion));
            if (result.botonesTemas) renderTopicButtons(result.botonesTemas, (num, text) => this.process(text));
        } else {
            const found = await this._crossModuleFallback(input);
            if (!found) {
                renderMessage('bot',
                    `No encontré información específica sobre **"${input}"**.\n\n` +
                    `💡 **Sugerencias:**\n` +
                    `- Usa palabras clave más específicas\n` +
                    `- Selecciona un módulo del menú y pregunta desde ahí\n` +
                    `- Ejemplos: _"monto máximo caja chica"_, _"viáticos Puebla 3 días"_, _"folio 15 sanciones"_`
                );
            }
        }
    }
}
